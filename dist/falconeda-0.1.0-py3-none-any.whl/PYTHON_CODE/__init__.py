__version__ = "0.1.0"
__author__ = "Riley Heiman"


from .main import run
#from .app import main  # Expose the main function from app.py

# Optional helper imports for ease of access
#from .utils import load_excel
#from .eda import perform_eda

